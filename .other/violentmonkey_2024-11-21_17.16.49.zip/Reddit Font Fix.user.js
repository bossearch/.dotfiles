// ==UserScript==
// @name        Reddit Font Fix
// @namespace   Violentmonkey Scripts
// @match        https://*.reddit.com/*
// @grant       none
// @version     1.0
// @author      -
// @description 11/21/2024, 5:14:16 PM
// ==/UserScript==

(function() {
    'use strict';
    const notoFont = "'Noto Sans', sans-serif";
    document.body.style.fontFamily = notoFont;
    const elements = document.querySelectorAll("*");
    elements.forEach(el => el.style.fontFamily = notoFont);
})();